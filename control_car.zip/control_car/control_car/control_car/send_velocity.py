import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class SendCmdVel(Node):
    def __init__(self):
        super().__init__('send_cmd_vel')
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)

        # Send increasing linear velocity gradually
        self.send_increasing_velocity()

    def send_increasing_velocity(self):
        twist_msg = Twist()
        twist_msg.linear.x = 0.0

        # Publish the Twist message with gradually increasing velocity
        while twist_msg.linear.x < 0.2:
            twist_msg.linear.x += 0.001  # Increase linear velocity by 0.01 at each iteration
            self.publisher.publish(twist_msg)
            self.get_logger().info('Sent Twist message with linear velocity: %f' % twist_msg.linear.x)
            rclpy.spin_once(self, timeout_sec=0.1)  # Allow processing of other events
        
def main(args=None):
    rclpy.init(args=args)
    send_cmd_vel_node = SendCmdVel()
    try:
        rclpy.spin(send_cmd_vel_node)
    except KeyboardInterrupt:
        pass
    send_cmd_vel_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

