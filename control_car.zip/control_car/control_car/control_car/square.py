import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import time

class SquareMovement(Node):
    def __init__(self):
        super().__init__('square_movement')
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)

    def move_forward(self, velocity, duration):
        twist_msg = Twist()
        twist_msg.linear.x = velocity

        start_time = time.time()
        while time.time() - start_time < duration:
            self.publisher.publish(twist_msg)

        # Stop the robot
        twist_msg.linear.x = 0.0
        self.publisher.publish(twist_msg)

    def rotate(self, angular_velocity, duration):
        twist_msg = Twist()
        twist_msg.angular.z = angular_velocity

        start_time = time.time()
        while time.time() - start_time < duration:
            self.publisher.publish(twist_msg)

        # Stop the robot
        twist_msg.angular.z = 0.0
        self.publisher.publish(twist_msg)

def main(args=None):
    rclpy.init(args=args)
    square_movement = SquareMovement()

    # Define parameters
    linear_velocity = 0.1  # linear velocity (m/s)
    angular_velocity = 0.1  # angular velocity (rad/s)
    forward_duration = 1.0  # duration to move forward (seconds)
    stop_duration = 3.0  # duration to stop (seconds)
    rotate_duration = 0.4  # duration to rotate (seconds)
    num_iterations = 4  # number of square pattern iterations
    
    #square_movement.move_forward(linear_velocity,0.8)
    try:
        for _ in range(num_iterations):
            time.sleep(stop_duration)
            # Move forward
            square_movement.move_forward(linear_velocity, forward_duration)

            # Stop for 3 seconds
            time.sleep(stop_duration)

            # Rotate
            square_movement.rotate(angular_velocity, rotate_duration)

            # Stop for 3 seconds
            #time.sleep(1.5)

    except KeyboardInterrupt:
        pass

    # Reset all values to 0 to stop the car
    twist_msg = Twist()
    twist_msg.linear.x = 0.0
    twist_msg.angular.z = 0.0
    square_movement.publisher.publish(twist_msg)

    square_movement.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
