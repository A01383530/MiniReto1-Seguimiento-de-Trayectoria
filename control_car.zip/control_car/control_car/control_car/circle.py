import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class ConstantTwistPublisher(Node):
    def __init__(self):
        super().__init__('constant_twist_publisher')
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.timer = self.create_timer(0.1, self.timer_callback)

    def timer_callback(self):
        # Create a Twist message
        twist_msg = Twist()

        # Set constant values for linear.x and angular.z
        twist_msg.linear.x = 0.1  # Constant linear velocity
        twist_msg.angular.z = 0.05  # Constant angular velocity

        # Publish the Twist message
        self.publisher.publish(twist_msg)
        self.get_logger().info('Sent Twist message with linear velocity: %f and angular velocity: %f' % (twist_msg.linear.x, twist_msg.angular.z))

def main(args=None):
    rclpy.init(args=args)
    constant_twist_publisher = ConstantTwistPublisher()
    try:
        rclpy.spin(constant_twist_publisher)
    except KeyboardInterrupt:
        pass
    constant_twist_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
